#!/usr/bin/env bash

# =============================================================================
# NFTBan Blacklist Module - Enhanced with Comprehensive Protection
# Version: 1.1.0
# Author: ITCMS Team (Antonios Voulvoulis)
# Contact: contact@itcms.gr
# Website: https://itcms.gr
# Ban operations with complete safety checks
# =============================================================================

# Prevent double-loading
[[ -n "${NFTBAN_BLACKLIST_LOADED:-}" ]] && return 0
readonly NFTBAN_BLACKLIST_LOADED=1

# =============================================================================
# MODULE CONFIGURATION
# =============================================================================
readonly NFTBAN_BLACKLIST_PERSISTENT="${NFTBAN_CONFIG_DIR}/blacklist-persistent.conf"
readonly NFTBAN_BLACKLIST_USER="${NFTBAN_CONFIG_DIR}/blacklist-user.conf"
readonly NFTBAN_RATE_LIMIT_FILE="${NFTBAN_DATA_DIR}/rate-limit-tracker.tmp"

# Ban settings (can be overridden in config)
NFTBAN_DEFAULT_BAN_TIME="${NFTBAN_DEFAULT_BAN_TIME:-3600}"
NFTBAN_PERSISTENT_THRESHOLD="${NFTBAN_PERSISTENT_THRESHOLD:-3}"
NFTBAN_RATE_LIMIT_PER_MIN="${NFTBAN_RATE_LIMIT_PER_MIN:-60}"

# =============================================================================
# INITIALIZATION
# =============================================================================

nftban_blacklist_init() {
    nftban_log_info "Initializing blacklist system..."
    
    mkdir -p "$NFTBAN_CONFIG_DIR" "$NFTBAN_DATA_DIR"
    
    # Create persistent blacklist
    if [[ ! -f "$NFTBAN_BLACKLIST_PERSISTENT" ]]; then
        cat > "$NFTBAN_BLACKLIST_PERSISTENT" << 'EOF'
# =============================================================================
# nftban Persistent Blacklist
# =============================================================================
# Auto-managed: IPs that have been banned multiple times
# These are automatically added when threshold is exceeded
# Format: IP_ADDRESS  # Date - Reason
# =============================================================================

EOF
        chmod 644 "$NFTBAN_BLACKLIST_PERSISTENT"
        nftban_log_debug "Created persistent blacklist"
    fi
    
    # Create user blacklist
    if [[ ! -f "$NFTBAN_BLACKLIST_USER" ]]; then
        cat > "$NFTBAN_BLACKLIST_USER" << 'EOF'
# =============================================================================
# nftban User Blacklist
# =============================================================================
# Manually managed permanent bans
# Format: IP_ADDRESS  # Comment
# Examples:
#   192.0.2.100    # Known attacker
#   198.51.100.0/24  # Malicious network
# =============================================================================

EOF
        chmod 644 "$NFTBAN_BLACKLIST_USER"
        nftban_log_debug "Created user blacklist"
    fi
    
    # Initialize rate limit tracker
    touch "$NFTBAN_RATE_LIMIT_FILE"
    
    nftban_log_success "Blacklist system initialized"
}

# =============================================================================
# RATE LIMITING
# =============================================================================

nftban_blacklist_check_rate_limit() {
    local current_time one_minute_ago recent_count
    current_time=$(date +%s)
    one_minute_ago=$((current_time - 60))
    
    # Count recent ban attempts
    recent_count=$(awk -v cutoff="$one_minute_ago" '$1 >= cutoff' "$NFTBAN_RATE_LIMIT_FILE" 2>/dev/null | wc -l)
    
    if [[ $recent_count -ge $NFTBAN_RATE_LIMIT_PER_MIN ]]; then
        nftban_log_error "RATE LIMIT EXCEEDED: ${recent_count} bans/min (limit: ${NFTBAN_RATE_LIMIT_PER_MIN})"
        return 1
    fi
    
    return 0
}

nftban_blacklist_record_ban_attempt() {
    local current_time
    current_time=$(date +%s)
    
    echo "$current_time" >> "$NFTBAN_RATE_LIMIT_FILE"
    
    # Clean old entries (older than 2 minutes)
    local two_minutes_ago=$((current_time - 120))
    awk -v cutoff="$two_minutes_ago" '$1 >= cutoff' "$NFTBAN_RATE_LIMIT_FILE" > "${NFTBAN_RATE_LIMIT_FILE}.tmp" 2>/dev/null || true
    mv "${NFTBAN_RATE_LIMIT_FILE}.tmp" "$NFTBAN_RATE_LIMIT_FILE" 2>/dev/null || true
}

# =============================================================================
# TEMPORARY BAN OPERATIONS (Enhanced with All Safety Checks)
# =============================================================================

# Ban IP temporarily - COMPREHENSIVE PROTECTION
nftban_blacklist_ban_ip() {
    local ip="$1"
    local jail="${2:-manual}"
    local ban_time="${3:-$NFTBAN_DEFAULT_BAN_TIME}"
    
    # 1. Validate IP
    nftban_validate_ip "$ip" || return 1
    
    local ver
    ver=$(nftban_detect_ip_version "$ip")
    
    # 2. Check rate limit
    nftban_blacklist_check_rate_limit || {
        nftban_log_ban "$ip" "$jail" "DENIED" "Rate limit exceeded"
        return 1
    }
    
    nftban_blacklist_record_ban_attempt
    
    # 3. CRITICAL: Check if this is the current user's IP
    local current_user_ip
    current_user_ip=$(nftban_get_current_user_ip)
    
    if [[ -n "$current_user_ip" && "$current_user_ip" == "$ip" ]]; then
        nftban_log_error "⚠️  BLOCKED: Cannot ban current user's IP: $ip"
        nftban_log_error "This would cause immediate lockout!"
        nftban_log_ban "$ip" "$jail" "DENIED" "Current user IP - lockout prevention"
        
        # Auto-whitelist current user IP for safety
        if ! nftban_whitelist_check_ip "$ip"; then
            nftban_log_warning "Auto-whitelisting current user IP for safety..."
            echo "${ip}  # Current user (auto-protected on $(date +'%Y-%m-%d %H:%M:%S'))" >> \
                "${NFTBAN_CONFIG_DIR}/whitelist-user.conf"
            if declare -f nftban_whitelist_sync_to_nftables &>/dev/null; then
                nftban_whitelist_sync_to_nftables
            fi
        fi
        
        return 1
    fi
    
    # 4. CRITICAL: Check if this is a server IP
    if ip -o addr show 2>/dev/null | grep -qF "$ip"; then
        nftban_log_error "⚠️  BLOCKED: Cannot ban server's own IP: $ip"
        nftban_log_error "This would break server functionality!"
        nftban_log_ban "$ip" "$jail" "DENIED" "Server IP - self-protection"
        
        # Auto-whitelist if not already
        if ! grep -qE "^${ip}([[:space:]]|$)" "${NFTBAN_CONFIG_DIR}/whitelist-system.conf" 2>/dev/null; then
            echo "${ip}  # Server IP (auto-protected on $(date +'%Y-%m-%d'))" >> \
                "${NFTBAN_CONFIG_DIR}/whitelist-system.conf"
            if declare -f nftban_whitelist_sync_to_nftables &>/dev/null; then
                nftban_whitelist_sync_to_nftables
            fi
        fi
        
        return 1
    fi
    
    # 5. CRITICAL: Check whitelist (highest priority)
    if nftban_whitelist_check_ip "$ip"; then
        nftban_log_warning "IP $ip is whitelisted - BAN DENIED"
        nftban_log_ban "$ip" "$jail" "DENIED" "Whitelisted"
        return 1
    fi
    
    # 6. Check if already banned in any nftables set
    if nftban_check_nftables_table; then
        # Check temp_ban
        if nft list set "$NFTBAN_NFT_FAMILY" "$NFTBAN_NFT_TABLE" "temp_ban_v${ver}" 2>/dev/null | \
           grep -qE "(${ip}[[:space:],}]|${ip}\$)"; then
            nftban_log_warning "IP $ip already banned in temp_ban (skipping)"
            nftban_log_ban "$ip" "$jail" "ALREADY_BANNED" "Exists in temp_ban set"
            return 0
        fi
        
        # Check user_blacklist
        if nft list set "$NFTBAN_NFT_FAMILY" "$NFTBAN_NFT_TABLE" "user_blacklist_v${ver}" 2>/dev/null | \
           grep -qE "(${ip}[[:space:],}]|${ip}\$)"; then
            nftban_log_warning "IP $ip already in permanent user blacklist (skipping)"
            nftban_log_ban "$ip" "$jail" "ALREADY_BANNED" "Exists in user_blacklist"
            return 0
        fi
        
        # Check system_blacklist
        if nft list set "$NFTBAN_NFT_FAMILY" "$NFTBAN_NFT_TABLE" "system_blacklist_v${ver}" 2>/dev/null | \
           grep -qE "(${ip}[[:space:],}]|${ip}\$)"; then
            nftban_log_warning "IP $ip already in system blacklist (skipping)"
            nftban_log_ban "$ip" "$jail" "ALREADY_BANNED" "Exists in system_blacklist"
            return 0
        fi
        
        # Check feeds
        if nft list set "$NFTBAN_NFT_FAMILY" "$NFTBAN_NFT_TABLE" "feeds_v${ver}" 2>/dev/null | \
           grep -qE "(${ip}[[:space:],}]|${ip}\$)"; then
            nftban_log_warning "IP $ip already in threat feeds (skipping)"
            nftban_log_ban "$ip" "$jail" "ALREADY_BANNED" "Exists in feeds"
            return 0
        fi
    else
        nftban_log_error "nftables table not initialized"
        return 1
    fi
    
    # 7. Execute ban (all safety checks passed)
    if nft add element "$NFTBAN_NFT_FAMILY" "$NFTBAN_NFT_TABLE" "temp_ban_v${ver}" \
        "{ $ip timeout ${ban_time}s comment \"${jail}\" }" 2>/dev/null; then
        
        nftban_log_success "Banned $ip for ${ban_time}s (jail: $jail)"
        nftban_log_ban "$ip" "$jail" "BANNED" "Timeout: ${ban_time}s"
        
        # Check for persistent offender
        if nftban_blacklist_check_persistent_offender "$ip"; then
            local ban_count
            ban_count=$(grep -c "|${ip}|.*|BANNED|" "$NFTBAN_BAN_LOG" 2>/dev/null || echo "0")
            nftban_blacklist_add_permanent "$ip" "Repeat offender: ${ban_count} bans from ${jail}"
        fi
        
        return 0
    else
        nftban_log_error "Failed to ban $ip"
        nftban_log_ban "$ip" "$jail" "ERROR" "nftables add failed"
        return 1
    fi
}

# =============================================================================
# COMPREHENSIVE UNBAN (Removes from ALL locations)
# =============================================================================

nftban_blacklist_unban_ip() {
    local ip="$1"
    local jail="${2:-manual}"
    local force="${3:-false}"  # Force unban even from permanent lists
    
    # Validate IP
    nftban_validate_ip "$ip" || return 1
    
    local ver
    ver=$(nftban_detect_ip_version "$ip")
    
    if ! nftban_check_nftables_table; then
        nftban_log_error "nftables table not initialized"
        return 1
    fi
    
    local removed_from=()
    local failed_to_remove=()
    local warnings=()
    
    # 1. Remove from temp_ban set (always allowed)
    if nft list set "$NFTBAN_NFT_FAMILY" "$NFTBAN_NFT_TABLE" "temp_ban_v${ver}" 2>/dev/null | \
       grep -qE "(${ip}[[:space:],}]|${ip}\$)"; then
        if nft delete element "$NFTBAN_NFT_FAMILY" "$NFTBAN_NFT_TABLE" "temp_ban_v${ver}" "{ $ip }" 2>/dev/null; then
            removed_from+=("temp_ban_v${ver}")
        else
            failed_to_remove+=("temp_ban_v${ver}")
        fi
    fi
    
    # 2. Check and potentially remove from permanent blacklists
    if [[ "$force" == "true" ]]; then
        # Force mode: remove from permanent lists
        
        # Remove from user_blacklist nftables set
        if nft list set "$NFTBAN_NFT_FAMILY" "$NFTBAN_NFT_TABLE" "user_blacklist_v${ver}" 2>/dev/null | \
           grep -qE "(${ip}[[:space:],}]|${ip}\$)"; then
            if nft delete element "$NFTBAN_NFT_FAMILY" "$NFTBAN_NFT_TABLE" "user_blacklist_v${ver}" "{ $ip }" 2>/dev/null; then
                removed_from+=("user_blacklist_v${ver}")
            else
                failed_to_remove+=("user_blacklist_v${ver}")
            fi
        fi
        
        # Remove from system_blacklist nftables set
        if nft list set "$NFTBAN_NFT_FAMILY" "$NFTBAN_NFT_TABLE" "system_blacklist_v${ver}" 2>/dev/null | \
           grep -qE "(${ip}[[:space:],}]|${ip}\$)"; then
            if nft delete element "$NFTBAN_NFT_FAMILY" "$NFTBAN_NFT_TABLE" "system_blacklist_v${ver}" "{ $ip }" 2>/dev/null; then
                removed_from+=("system_blacklist_v${ver}")
            else
                failed_to_remove+=("system_blacklist_v${ver}")
            fi
        fi
        
        # Remove from blacklist files
        local blacklist_files=(
            "$NFTBAN_BLACKLIST_PERSISTENT"
            "$NFTBAN_BLACKLIST_USER"
        )
        
        for file in "${blacklist_files[@]}"; do
            if [[ -f "$file" ]] && grep -qE "^${ip}([[:space:]]|$)" "$file"; then
                if sed -i "/^${ip}[[:space:]]/d" "$file"; then
                    removed_from+=("$(basename "$file")")
                else
                    failed_to_remove+=("$(basename "$file")")
                fi
            fi
        done
    else
        # Normal mode: just inform about permanent locations
        
        if nft list set "$NFTBAN_NFT_FAMILY" "$NFTBAN_NFT_TABLE" "user_blacklist_v${ver}" 2>/dev/null | \
           grep -qE "(${ip}[[:space:],}]|${ip}\$)"; then
            warnings+=("IP is in permanent user blacklist")
        fi
        
        if nft list set "$NFTBAN_NFT_FAMILY" "$NFTBAN_NFT_TABLE" "system_blacklist_v${ver}" 2>/dev/null | \
           grep -qE "(${ip}[[:space:],}]|${ip}\$)"; then
            warnings+=("IP is in permanent system blacklist")
        fi
        
        if [[ -f "$NFTBAN_BLACKLIST_PERSISTENT" ]] && \
           grep -qE "^${ip}([[:space:]]|$)" "$NFTBAN_BLACKLIST_PERSISTENT"; then
            warnings+=("IP is in persistent blacklist (repeat offender)")
        fi
        
        if [[ -f "$NFTBAN_BLACKLIST_USER" ]] && \
           grep -qE "^${ip}([[:space:]]|$)" "$NFTBAN_BLACKLIST_USER"; then
            warnings+=("IP is in user blacklist file")
        fi
    fi
    
    # 3. Check feeds (cannot remove - feeds are read-only)
    if nft list set "$NFTBAN_NFT_FAMILY" "$NFTBAN_NFT_TABLE" "feeds_v${ver}" 2>/dev/null | \
       grep -qE "(${ip}[[:space:],}]|${ip}\$)"; then
        warnings+=("IP is in threat intelligence feeds (read-only)")
    fi
    
    # 4. Display warnings if any
    if [[ ${#warnings[@]} -gt 0 ]]; then
        for warning in "${warnings[@]}"; do
            nftban_log_warning "$warning"
        done
        
        if [[ "$force" != "true" ]]; then
            nftban_log_info "To remove from permanent lists, use: nftban unban --force $ip"
            nftban_log_info "To allow despite feeds, add to whitelist: nftban whitelist add $ip"
        fi
    fi
    
    # 5. Report results
    if [[ ${#removed_from[@]} -gt 0 ]]; then
        nftban_log_success "Unbanned $ip from: ${removed_from[*]}"
        nftban_log_ban "$ip" "$jail" "UNBANNED" "Removed from: ${removed_from[*]}"
        
        # Rebuild search index
        if declare -f nftban_search_build_index &>/dev/null; then
            nftban_search_build_index
        fi
        
        return 0
    elif [[ ${#failed_to_remove[@]} -gt 0 ]]; then
        nftban_log_error "Failed to unban $ip from: ${failed_to_remove[*]}"
        return 1
    else
        nftban_log_warning "IP $ip not found in any temporary ban list"
        return 1
    fi
}

# =============================================================================
# PERSISTENT OFFENDER MANAGEMENT
# =============================================================================

# Check if IP is a persistent offender
nftban_blacklist_check_persistent_offender() {
    local ip="$1"
    local threshold="$NFTBAN_PERSISTENT_THRESHOLD"
    
    [[ "$threshold" == "0" ]] && return 1
    [[ ! -f "$NFTBAN_BAN_LOG" ]] && return 1
    
    local ban_count
    ban_count=$(grep -c "|${ip}|.*|BANNED|" "$NFTBAN_BAN_LOG" 2>/dev/null || echo "0")
    
    if [[ $ban_count -ge $threshold ]]; then
        nftban_log_warning "IP $ip is persistent offender ($ban_count bans, threshold: $threshold)"
        return 0
    fi
    
    return 1
}

# Add IP to persistent blacklist (with comprehensive safety checks)
nftban_blacklist_add_permanent() {
    local ip="$1"
    local reason="${2:-Manual permanent ban}"
    
    # Validate IP
    nftban_validate_ip "$ip" || return 1
    
    local ver
    ver=$(nftban_detect_ip_version "$ip")
    
    # CRITICAL SAFETY CHECKS (same as ban function)
    
    # 1. Check if IP is whitelisted
    if nftban_whitelist_check_ip "$ip"; then
        nftban_log_error "⚠️  BLOCKED: Cannot blacklist whitelisted IP: $ip"
        nftban_log_error "Remove from whitelist first if you really want to ban this IP"
        return 1
    fi
    
    # 2. Check if this is server IP
    if ip -o addr show 2>/dev/null | grep -qF "$ip"; then
        nftban_log_error "⚠️  BLOCKED: Cannot blacklist server's own IP: $ip"
        return 1
    fi
    
    # 3. Check if this is current user IP
    local current_ip
    current_ip=$(nftban_get_current_user_ip)
    if [[ -n "$current_ip" && "$current_ip" == "$ip" ]]; then
        nftban_log_error "⚠️  BLOCKED: Cannot blacklist current user's IP: $ip"
        nftban_log_error "This would cause immediate lockout!"
        return 1
    fi
    
    # 4. Check for duplicates
    local existing_locations
    existing_locations=$(nftban_find_ip_locations "$ip")
    
    if [[ -n "$existing_locations" ]]; then
        nftban_log_info "IP $ip already exists in:"
        echo "$existing_locations" | while read -r location; do
            nftban_log_info "  - $location"
        done
        
        # If already in permanent blacklist, skip
        if echo "$existing_locations" | grep -q "user_blacklist\|blacklist-persistent"; then
            nftban_log_info "IP already in permanent blacklist, skipping"
            return 0
        fi
    fi
    
    # 5. Add to persistent blacklist file
    if ! grep -qE "^${ip}([[:space:]]|$)" "$NFTBAN_BLACKLIST_PERSISTENT" 2>/dev/null; then
        local timestamp
        timestamp=$(date +'%Y-%m-%d %H:%M:%S')
        echo "${ip}  # ${timestamp} - ${reason}" >> "$NFTBAN_BLACKLIST_PERSISTENT"
        nftban_log_success "Added $ip to permanent blacklist file"
    else
        nftban_log_info "IP already in persistent blacklist file"
    fi
    
    # 6. Add to nftables user_blacklist set
    if nftban_check_nftables_table; then
        if ! nft list set "$NFTBAN_NFT_FAMILY" "$NFTBAN_NFT_TABLE" "user_blacklist_v${ver}" 2>/dev/null | \
           grep -qE "(${ip}[[:space:],}]|${ip}\$)"; then
            
            if nft add element "$NFTBAN_NFT_FAMILY" "$NFTBAN_NFT_TABLE" "user_blacklist_v${ver}" "{ $ip }" 2>/dev/null; then
                nftban_log_success "Added $ip to permanent blacklist (nftables)"
            else
                nftban_log_warning "Failed to add to nftables (already in file)"
            fi
        else
            nftban_log_info "IP already in nftables user_blacklist set"
        fi
    else
        nftban_log_success "Added $ip to permanent blacklist file only"
    fi
    
    nftban_log_ban "$ip" "PERSISTENT" "PERMANENT" "$reason"
    
    # 7. Remove from temp_ban if exists (upgrade to permanent)
    if nft list set "$NFTBAN_NFT_FAMILY" "$NFTBAN_NFT_TABLE" "temp_ban_v${ver}" 2>/dev/null | \
       grep -qE "(${ip}[[:space:],}]|${ip}\$)"; then
        nft delete element "$NFTBAN_NFT_FAMILY" "$NFTBAN_NFT_TABLE" "temp_ban_v${ver}" "{ $ip }" 2>/dev/null
        nftban_log_info "Upgraded from temporary to permanent ban"
    fi
    
    # Rebuild search index
    if declare -f nftban_search_build_index &>/dev/null; then
        nftban_search_build_index
    fi
    
    return 0
}

# Remove IP from persistent blacklist
nftban_blacklist_remove_permanent() {
    local ip="$1"
    
    # Validate IP
    nftban_validate_ip "$ip" || return 1
    
    local ver
    ver=$(nftban_detect_ip_version "$ip")
    
    local removed=false
    
    # Remove from files
    for file in "$NFTBAN_BLACKLIST_PERSISTENT" "$NFTBAN_BLACKLIST_USER"; do
        if [[ -f "$file" ]] && grep -qE "^${ip}([[:space:]]|$)" "$file"; then
            sed -i "/^${ip}[[:space:]]/d" "$file"
            nftban_log_success "Removed $ip from $(basename "$file")"
            removed=true
        fi
    done
    
    # Remove from nftables
    if nftban_check_nftables_table; then
        if nft delete element "$NFTBAN_NFT_FAMILY" "$NFTBAN_NFT_TABLE" "user_blacklist_v${ver}" "{ $ip }" 2>/dev/null; then
            nftban_log_success "Removed $ip from nftables user_blacklist"
            removed=true
        fi
    fi
    
    if [[ "$removed" == true ]]; then
        # Rebuild search index
        if declare -f nftban_search_build_index &>/dev/null; then
            nftban_search_build_index
        fi
        
        nftban_log_ban "$ip" "MANUAL" "UNBLACKLISTED" "Removed from permanent blacklist"
        return 0
    else
        nftban_log_warning "IP $ip not found in permanent blacklist"
        return 1
    fi
}

# =============================================================================
# LIST & DISPLAY
# =============================================================================

# List permanent blacklist
nftban_blacklist_list_permanent() {
    echo ""
    echo "═══════════════════════════════════════════════════════"
    echo "  Permanent Blacklist"
    echo "═══════════════════════════════════════════════════════"
    echo ""
    
    echo -e "${NFTBAN_CYAN}Persistent Offenders (Auto-added):${NFTBAN_NC}"
    if [[ -f "$NFTBAN_BLACKLIST_PERSISTENT" ]]; then
        grep -E "^[0-9a-fA-F.:]+([[:space:]]|$)" "$NFTBAN_BLACKLIST_PERSISTENT" 2>/dev/null | nl -w3 -s'. ' || echo "  (empty)"
    else
        echo "  File not found"
    fi
    echo ""
    
    echo -e "${NFTBAN_CYAN}User Blacklist (Manual):${NFTBAN_NC}"
    if [[ -f "$NFTBAN_BLACKLIST_USER" ]]; then
        grep -E "^[0-9a-fA-F.:]+([[:space:]]|$)" "$NFTBAN_BLACKLIST_USER" 2>/dev/null | nl -w3 -s'. ' || echo "  (empty)"
    else
        echo "  File not found"
    fi
    echo ""
    
    # Show nftables sets if available
    if nftban_check_nftables_table; then
        echo -e "${NFTBAN_CYAN}nftables Sets:${NFTBAN_NC}"
        for ver in 4 6; do
            for set_type in user_blacklist system_blacklist temp_ban feeds; do
                if nft list set "$NFTBAN_NFT_FAMILY" "$NFTBAN_NFT_TABLE" "${set_type}_v${ver}" &>/dev/null; then
                    local count
                    count=$(nft list set "$NFTBAN_NFT_FAMILY" "$NFTBAN_NFT_TABLE" "${set_type}_v${ver}" 2>/dev/null | \
                            grep -oP 'elements = \{\K[^}]*' | grep -o '[0-9a-fA-F.:]\+' | wc -l)
                    printf "  %-25s %3d IPs\n" "${set_type}_v${ver}:" "$count"
                fi
            done
        done
        echo ""
    fi
}

# =============================================================================
# SYNC & MAINTENANCE
# =============================================================================

# Sync blacklist to nftables
nftban_blacklist_sync_to_nftables() {
    nftban_log_info "Syncing blacklist to nftables..."
    
    if ! nftban_check_nftables_table; then
        nftban_log_error "nftables table not initialized"
        return 1
    fi
    
    # Flush existing blacklist sets
    nft flush set "$NFTBAN_NFT_FAMILY" "$NFTBAN_NFT_TABLE" user_blacklist_v4 2>/dev/null || true
    nft flush set "$NFTBAN_NFT_FAMILY" "$NFTBAN_NFT_TABLE" user_blacklist_v6 2>/dev/null || true
    
    local synced_v4=0
    local synced_v6=0
    
    # Process blacklist files
    local blacklist_files=(
        "$NFTBAN_BLACKLIST_PERSISTENT"
        "$NFTBAN_BLACKLIST_USER"
    )
    
    for file in "${blacklist_files[@]}"; do
        [[ ! -f "$file" ]] && continue
        
        while IFS= read -r line; do
            [[ "$line" =~ ^[[:space:]]*# ]] && continue
            [[ -z "$line" ]] && continue
            
            local ip
            ip=$(echo "$line" | awk '{print $1}')
            [[ -z "$ip" ]] && continue
            
            # Detect IP version and add to appropriate set
            local ver
            ver=$(nftban_detect_ip_version "$ip")
            
            if [[ "$ver" == "4" ]]; then
                if nft add element "$NFTBAN_NFT_FAMILY" "$NFTBAN_NFT_TABLE" user_blacklist_v4 "{ $ip }" 2>/dev/null; then
                    ((synced_v4++))
                fi
            elif [[ "$ver" == "6" ]]; then
                if nft add element "$NFTBAN_NFT_FAMILY" "$NFTBAN_NFT_TABLE" user_blacklist_v6 "{ $ip }" 2>/dev/null; then
                    ((synced_v6++))
                fi
            fi
        done < "$file"
    done
    
    nftban_log_success "Synced to nftables: $synced_v4 IPv4, $synced_v6 IPv6"
    
    return 0
}

# =============================================================================
# STATISTICS
# =============================================================================

# Show recent ban statistics
nftban_blacklist_show_recent_stats() {
    if [[ ! -f "$NFTBAN_BAN_LOG" ]]; then
        echo "  No ban data available"
        return 0
    fi
    
    local cutoff_time
    cutoff_time=$(date -d '24 hours ago' +'%Y-%m-%d %H:%M:%S' 2>/dev/null || \
                  date -v-24H +'%Y-%m-%d %H:%M:%S' 2>/dev/null)
    
    if [[ -n "$cutoff_time" ]]; then
        local total_bans denied_bans permanent_bans
        total_bans=$(awk -F'|' -v cutoff="$cutoff_time" '$1 >= cutoff && $4 == "BANNED"' "$NFTBAN_BAN_LOG" | wc -l)
        denied_bans=$(awk -F'|' -v cutoff="$cutoff_time" '$1 >= cutoff && $4 == "DENIED"' "$NFTBAN_BAN_LOG" | wc -l)
        permanent_bans=$(awk -F'|' -v cutoff="$cutoff_time" '$1 >= cutoff && $4 == "PERMANENT"' "$NFTBAN_BAN_LOG" | wc -l)
        
        echo "  Bans: $total_bans | Denied: $denied_bans | Permanent: $permanent_bans"
    fi
}

# Get top banned IPs
nftban_blacklist_get_top_ips() {
    local limit="${1:-10}"
    
    if [[ ! -f "$NFTBAN_BAN_LOG" ]]; then
        return 0
    fi
    
    awk -F'|' '$4 == "BANNED" {print $2}' "$NFTBAN_BAN_LOG" | \
        sort | uniq -c | sort -rn | head -n "$limit"
}

# Get ban count for IP
nftban_blacklist_get_ip_ban_count() {
    local ip="$1"
    
    if [[ ! -f "$NFTBAN_BAN_LOG" ]]; then
        echo "0"
        return 0
    fi
    
    grep -c "|${ip}|.*|BANNED|" "$NFTBAN_BAN_LOG" 2>/dev/null || echo "0"
}

# =============================================================================
# EXPORT FUNCTIONS
# =============================================================================
export -f nftban_blacklist_init
export -f nftban_blacklist_check_rate_limit
export -f nftban_blacklist_record_ban_attempt
export -f nftban_blacklist_ban_ip
export -f nftban_blacklist_unban_ip
export -f nftban_blacklist_check_persistent_offender
export -f nftban_blacklist_add_permanent
export -f nftban_blacklist_remove_permanent
export -f nftban_blacklist_list_permanent
export -f nftban_blacklist_sync_to_nftables
export -f nftban_blacklist_show_recent_stats
export -f nftban_blacklist_get_top_ips
export -f nftban_blacklist_get_ip_ban_count

nftban_log_debug "NFTBan Blacklist Module loaded (v1.1.0 - Comprehensive Protection)"
